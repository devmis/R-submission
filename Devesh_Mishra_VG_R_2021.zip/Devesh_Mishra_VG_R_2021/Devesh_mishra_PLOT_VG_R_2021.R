library(tidyverse)
library(tidyr)
library(dplyr)
library(stringr)
library(ggplot2)
library(ggforce)
library(plotrix)

x1 <- runif(1000, 0, 1)
y1 <- runif(1000, 0, 1)
sqrt1 <- sqrt(x1^2+y1^2)
sqrt1

plot(x1[which(sqrt1<=1)], y1[which(sqrt1<=1)], xlim = c(0,1), ylim = c(0,1))+
  points(x1[which(sqrt1>1)],y1[which(sqrt1>1)],col='blue')+
  points(x1[which(sqrt1<=0.4)],y1[which(sqrt1<=0.4)],col='red')+
  points(x1[which(sqrt1>0.4 & sqrt1<=0.8)],y1[which(sqrt1>0.4 & sqrt1 <=0.8)],col='green')+
  draw.ellipse(0,0,0.4,0.4, border="red", lwd = 2 ) + 
  draw.ellipse(0,0,0.8,0.8, border="blue", lwd = 2 )+
  draw.ellipse(0,0,1,1, border="black", lwd = 2)



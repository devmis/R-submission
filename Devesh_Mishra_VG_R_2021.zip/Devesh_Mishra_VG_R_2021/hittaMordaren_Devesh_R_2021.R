#Relevant f?r G och VG:

#Tidpunkt f?r n?r telefonen ringde hittar ni i kolonnen time0. 
#Mordet ?gde rum vid tidpunkt time0 = 416 +/- 9 minuter.
#M?rdaren ringde ifr?n en iPhone
#F?rs?k att hitta ett uttryck f?r detta tidsspann och hitta max 6 misst?nkta!




#ENDAST RELEVANT INFO F?R VG:
#Mordet ?gde rum vid koordinaterna X = 2.22, Y = 2.92.  Ta hj?lp av denna 
#informationen f?r att hitta m?rdaren!

#timem1, timem2 och timem3 m?ter tidpunkten d? masterna tog emot signalen fr?n 
#k?llan vid tidpunkt time0 som telefonen ringde ifr?n. Fundera p? vad som ?r 
#relevant f?r att r?kna ut avst?ndet till k?llan - ?r time0 i sig viktig eller 
#?r det differenserna timem1 - time0, timem2 - time0 och timem3 - time0?

#Kolla i filen triangulation.r. Du ska anv?nda denna f?r att hj?lpa dig hitta 
#m?rdaren och beh?ver INTE g?ra n?gra ?ndringar i triangulation.r. Du beh?ver 
#inte f?rst? den till fullo. 
#Du vill kalla p? mainfunktionen circle_intersection som tar in en 3x3-matris 
#med f?ljande information (till exempel):

example_matrix <- matrix(c(4,7,2,6,4,1,6,6,7), ncol = 3, byrow = TRUE)
#Att namnge kolonner beh?vs inte, men finns h?r som f?rtydligande f?r v?ntat 
#format p? input till circle_intersection.
colnames(example_matrix) <- c("X-coord_mast", "Y-coord_mast", "Avst?nd till k?lla")
rownames(example_matrix) <- c("Mast 1", "Mast 2", "Mast 3")
print(example_matrix)
# H?mtar triangulation filen f?rutsatt den finns i samma working directory.
# p? detta s?ttet kan vi h?mta funktionen circle_intersection utan att kopiera 
# koden till denna filen
source("triangulation.r", encoding = "latin1")
koordinater <- circle_intersection(example_matrix)
koordinater
# x- och y-koordinater till var mobilen befann sig.  


#Variabler:

#Hastighet att anv?nda vid skalning av tid f?r att f? ut distans till mastar. 
#Telefonsignaler breder ut sig radiellt med uuuungef?r ljusets hastighet.
velocity <- 3*10^8

#De fasta koordinaterna f?r masterna. Allts? var masterna befinner sig i ett 
# x-, y-plan. Foga samman denna information med ditt ber?knade avst?nd till 
#k?llan med tid omgjord till distans
master <- matrix(c(4,7,6,4,6,6), ncol = 2, byrow = TRUE)

#Din kod f?ljer h?r. Du f?r g?rna kopiera koden fr?n triangulation.r h?r eller  
#anv?nda source som visat ovan

#Lycka till! :)

#Part 2 Suspect
library(tidyverse)
source("triangulation.r", encoding = "latin1")
velocity <- 3*10^8
telemastdata_copy <- read_csv("telemastdata.csv")
View(telemastdata_copy)
head(telemastdata_copy)
murderer_profile<-telemastdata_copy %>%  
  filter( phone_type == "iPhone" &
            time0 >= 407 &
            time0 <= 425) %>%
  group_by(time0)
View(murderer_profile)
as.data.frame(murderer_profile)

diff_1 <- (murderer_profile$timem1-murderer_profile$time0)*velocity
diff_2 <- (murderer_profile$timem2-murderer_profile$time0)*velocity
diff_3 <- (murderer_profile$timem3-murderer_profile$time0)*velocity
murder_suspect <- as.data.frame(rbind(diff_1, diff_2, diff_3)) 
murder_suspect

round_murder_suspect <- round(murder_suspect, 2) 

master <- matrix(c(4,7,6,4,6,6), ncol = 2, byrow = TRUE)
master

Jonas_Nilsson <- cbind(master,round_murder_suspect$V1)
Jonas_Nilsson
Kerim_Grenkvistgren <-cbind(master,round_murder_suspect$V2)
Kerim_Grenkvistgren
Maria_Kvistgren <-cbind(master,round_murder_suspect$V3)
Maria_Kvistgren
Morritz_Grenkvist <-cbind(master,round_murder_suspect$V4)
Morritz_Grenkvist
Morritz_Hempel <-cbind(master,round_murder_suspect$V5)
Morritz_Hempel
Peter_Moss <-cbind(master,round_murder_suspect$V6)
Peter_Moss

kordinate_1 <- circle_intersection(Jonas_Nilsson)
kordinate_1

kordinate_2 <- circle_intersection(Kerim_Grenkvistgren)
kordinate_2

kordinate_3 <- circle_intersection(Maria_Kvistgren)
kordinate_3

kordinate_4 <- circle_intersection(Morritz_Grenkvist)
kordinate_4

kordinate_5 <- circle_intersection(Morritz_Hempel)
kordinate_5

kordinate_6 <- circle_intersection(Peter_Moss)
kordinate_6

#svar är Morritz_Hemple med kordinate_5

kordinates <- cbind(kordinate_1, kordinate_2, kordinate_3, kordinate_4, kordinate_5, kordinate_6)
dim(kordinates)
as.data.frame(kordinates)
transpose_kordinates <- t(kordinates)
transpose_kordinates <- as.data.frame(transpose_kordinates)
transpose_kordinates <- transpose_kordinates %>% separate(V1, c("xcord", "ycord"), sep = ",")
transpose_kordinates <- 
  data.frame(as.numeric(transpose_kordinates$xcord),as.numeric(transpose_kordinates$ycord))
summary(transpose_kordinates)
new_transpose_kordinates <- 
  data.frame (murderer_profile$name,
    round(transpose_kordinates$as.numeric.transpose_kordinates.xcord., 2), 
              round(transpose_kordinates$as.numeric.transpose_kordinates.ycord., 2))
new_transpose_kordinates[new_transpose_kordinates$round.transpose_kordinates.as.numeric.transpose_kordinates.xcord...== 2.22 & new_transpose_kordinates$round.transpose_kordinates.as.numeric.transpose_kordinates.ycord...== 2.92,] 





